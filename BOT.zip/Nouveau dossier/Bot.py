import discord
from discord.ext import commands, tasks
import aiohttp
import os
from dotenv import load_dotenv

# Charger les variables d'environnement depuis le fichier .env
load_dotenv()

# Récupération sécurisée du token
TOKEN = os.getenv("DISCORD_TOKEN")

if not TOKEN:
    raise ValueError("Le token Discord est introuvable dans le fichier .env.")

# Liste des serveurs BeamMP à suivre
SERVERS_TO_TRACK = [
    {"ip": "82.153.202.50", "port": "30821"},  # Norvege # Clef Max
    {"ip": "82.153.202.50", "port": "30822"},  # Norvege # Clef Max
    {"ip": "82.153.202.50", "port": "30816"},  # offroad 01 # Quevin
    {"ip": "82.153.202.50", "port": "30823"},  # offroad 02 # Quevin
    {"ip": "82.153.202.50", "port": "30817"},  # Derby # Kakarot
    {"ip": "82.153.202.50", "port": "30824"},  # Derby # Kakarot
    {"ip": "82.153.202.50", "port": "30829"},  # Derby # Djo Lopez
    {"ip": "82.153.202.50", "port": "30831"},  # Derby # Djo Lopez


]

# Ajoutez l'ID du canal Discord
CHANNEL_ID = 1363881821435334807  # Remplacez par l'ID de votre canal

# Configuration des intents
intents = discord.Intents.default()
intents.message_content = True  # Pour les commandes basées sur le contenu des messages

# Création du bot
bot = commands.Bot(command_prefix="!", intents=intents)

# Variables globales pour le statut
status_cycle = []
status_index = 0

@bot.event
async def on_ready():
    print(f"✅ Connecté en tant que {bot.user}")
    fetch_server_data.start()
    rotate_status.start()

@tasks.loop(minutes=5)
async def fetch_server_data():
    global status_cycle
    url = "https://backend.beammp.com/servers-info"
    status_cycle = []

    try:
        print("🔄 Début de la récupération des serveurs...")
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as resp:
                print(f"Statut de la réponse : {resp.status}")  # Log du statut HTTP
                if resp.status == 200:
                    servers = await resp.json()
                    print("📡 Données récupérées des serveurs BeamMP :", servers)  # Log des données brutes
                    channel = bot.get_channel(CHANNEL_ID)  # Obtenez le canal Discord
                    if not channel:
                        print(f"❌ Impossible de trouver le canal avec l'ID {CHANNEL_ID}")
                        return

                    # Supprimez tous les messages du canal
                    await channel.purge()

                    # Construisez le message avec les informations des serveurs
                    message_content = "**📊 Informations des serveurs suivis :**\n\n"
                    for tracked in SERVERS_TO_TRACK:
                        match = next((s for s in servers if s["ip"] == tracked["ip"] and s["port"] == tracked["port"]), None)
                        if match:
                            name = match.get("sname", "Serveur inconnu")
                            players = match.get("players", "0")
                            max_players = match.get("maxplayers", "?")
                            map_name = match.get("map", "Inconnue")
                            status_msg = f"{players} joueurs sur {name}"
                            status_cycle.append(status_msg)

                            # Ajoutez les informations au message
                            message_content += (
                                f"**🟢 {name}**\n"
                                f"> **IP :** `{tracked['ip']}:{tracked['port']}`\n"
                                f"> **Joueurs :** `{players}/{max_players}`\n"
                                f"> **Carte :** `{map_name}`\n\n"
                            )
                            print(f"✅ {name} ({tracked['ip']}:{tracked['port']})")
                        else:
                            offline_msg = f"Hors ligne : {tracked['ip']}:{tracked['port']}"
                            status_cycle.append(offline_msg)
                            message_content += (
                                f"**🔴 Hors ligne**\n"
                                f"> **IP :** `{tracked['ip']}:{tracked['port']}`\n\n"
                            )
                            print(f"❌ Serveur non trouvé ou hors ligne : {tracked['ip']}:{tracked['port']}")

                    # Envoyez le message dans le canal Discord
                    if channel:
                        await channel.send(message_content)
                else:
                    status_cycle = ["Erreur API (code)"]
                    print(f"⚠️ Erreur API BeamMP : statut {resp.status}")
    except Exception as e:
        print("❌ Erreur API :", e)
        status_cycle = ["API inaccessible"]

@tasks.loop(seconds=120)
async def rotate_status():
    global status_index
    if not status_cycle:
        return
    current_status = status_cycle[status_index]
    await bot.change_presence(activity=discord.Game(name=current_status))
    status_index = (status_index + 1) % len(status_cycle)

# Démarrer le bot
bot.run(TOKEN)